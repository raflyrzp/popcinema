<footer id="wpdevart-footer">
	<p class="text-center">Powered by <a href="https://wpdevart.com/" target="_blank">WpDevArt</a>. All rights reserved</p>
</footer>