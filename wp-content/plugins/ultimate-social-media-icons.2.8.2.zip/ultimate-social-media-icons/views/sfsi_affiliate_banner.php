<style type="text/css">
.tab11 .save_button{padding-bottom: 20px;}div#accordion2 {margin-top: 20px;}
#accordion2 h3 span {position: absolute;left: 0;top: 0;width: 50px;height: 49px;background: #31373d;line-height: 50px;text-align: center;font-family: helveticaregular;font-size: 20px;color: #FFF;}
.tab11 img{min-height: 150px;min-width: 150px;margin-left: auto;margin-right: auto;text-align: center;display: table-cell;vertical-align: middle;}
</style>
<div id="accordion2">
    <h3><span>$</span><?php _e("Share the premium plugin and earn 40% of the purchase price!",'ultimate-social-media-icons') ?></h3>
    <!-- Affiliate banner html start here -->

    <div class="tab11">
        <a target="_blank" href="https://goo.gl/6w2Rg5"><img src="<?php echo SFSI_PLUGURL ?>images/affiliate_banner.png" alt="Affiliate Banner" /></a>
    </div>
</div>
