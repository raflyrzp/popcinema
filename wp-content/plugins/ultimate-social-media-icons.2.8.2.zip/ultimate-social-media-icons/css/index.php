<?php
	
	_e( 'Access Denied', 'ultimate-social-media-icons' );