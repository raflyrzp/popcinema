<?php
namespace AIOWPS\Firewall;

/**
 * Our list of families
 */
return array(
	array('name' => '6G', 'priority' => 10),
	array('name' => 'Blacklist', 'priority' => 1),
	array('name' => 'Bruteforce', 'priority' => 0),
	array('name' => 'General', 'priority' => 20),
);
