<?php
/**
 * Holds copies of WordPress 4.7 functions for forward compatibilty.
 *
 * @package The_SEO_Framework\Compat\WP\470
 * @subpackage WordPress
 * @license GPLv2+
 */

defined( 'THE_SEO_FRAMEWORK_PRESENT' ) or die;
