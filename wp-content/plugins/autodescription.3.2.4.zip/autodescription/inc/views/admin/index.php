<?php
/**
 * Private property began the instant somebody had a mind of his own.
 *
 * - Edward Estlin "E. E." Cummings
 */
