<?php

namespace Yoast\WP\SEO\Exceptions\Addon_Installation;

use Exception;

/**
 * Class User_Cannot_Install_Plugins_Exception
 */
class User_Cannot_Install_Plugins_Exception extends Exception {}
