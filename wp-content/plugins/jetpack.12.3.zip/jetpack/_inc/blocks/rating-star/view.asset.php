<?php return array('dependencies' => array('wp-polyfill'), 'version' => '09a108e1bb13e6638e50');
