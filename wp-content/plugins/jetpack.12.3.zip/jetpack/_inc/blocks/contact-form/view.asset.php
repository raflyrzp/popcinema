<?php return array('dependencies' => array('wp-polyfill'), 'version' => '87165ee4e0dbb506240d');
