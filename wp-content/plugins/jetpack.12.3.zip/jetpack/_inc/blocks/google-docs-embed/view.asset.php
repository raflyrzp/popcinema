<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '5bc9866eff9151bba3ae');
