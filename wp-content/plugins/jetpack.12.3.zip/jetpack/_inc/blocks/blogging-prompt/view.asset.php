<?php return array('dependencies' => array('wp-polyfill'), 'version' => '7c2de9bcd20c185fc607');
