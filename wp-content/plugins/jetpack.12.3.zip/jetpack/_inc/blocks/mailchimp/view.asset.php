<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'd9f5af0178682358fe63');
