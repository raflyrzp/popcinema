<?php return array('dependencies' => array('wp-polyfill'), 'version' => '80139ca104c5c701e085');
