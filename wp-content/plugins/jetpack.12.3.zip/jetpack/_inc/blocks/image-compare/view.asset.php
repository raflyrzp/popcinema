<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '03a2814a99e2d9c9f581');
