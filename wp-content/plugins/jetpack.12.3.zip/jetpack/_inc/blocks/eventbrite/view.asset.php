<?php return array('dependencies' => array('wp-polyfill'), 'version' => '90942691078d44b67246');
